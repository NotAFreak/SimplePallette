﻿using SimplePallete.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SimplePallete
{
    /// <summary>
    /// Interaction logic for ColorPickerWindow.xaml
    /// </summary>
    public partial class ColorPickerWindow : Window
    {
        ColorObject colorObject;
        public ColorPickerWindow(ColorObject colObj)
        {
            InitializeComponent();

            Focus();
            ((App)Application.Current).SetColorPickerWindowReference(this);
            colorObject = colObj;
        }

        private void cp_MainColorPicker_ColorChanged(object sender, RoutedEventArgs e)
        {
            //hehe can you hear me god? it's me, Margaret
            colorObject.color = Color.FromScRgb((float)cp_MainColorPicker.Color.A,(float)cp_MainColorPicker.Color.RGB_R, (float)cp_MainColorPicker.Color.RGB_G, (float)cp_MainColorPicker.Color.RGB_B);
        }

    }
}
