﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SimplePallete
{
    /// <summary>
    /// Interaction logic for OptionsWindow.xaml
    /// </summary>
    public partial class OptionsWindow : Window
    {
        public OptionsWindow()
        {
            InitializeComponent();

            ((App)Application.Current).SetOptionsWindowReference(this);
            
            chk_TopMost.IsChecked = ((App)Application.Current).bTopMost;
            switch(((App)Application.Current).resizeMode)
            {
                case ResizeMode.CanResize:
                    chk_ResizeGrip.IsChecked = false;
                    break;
                default:
                    chk_ResizeGrip.IsChecked = true;
                    break;
            }
            switch(((App)Application.Current).iAppTheme)
            {
                case 0:
                    rdbtn_DarkTheme.IsChecked = true;
                    rdbtn_LightTheme.IsChecked = false;
                    break;
                case 1:
                    rdbtn_DarkTheme.IsChecked = false;
                    rdbtn_LightTheme.IsChecked = true;
                    break;
            }

            Topmost = ((App)Application.Current).bTopMost;
            ResizeMode = ((App)Application.Current).resizeMode;
        }

        private void chk_TopMost_Checked(object sender, RoutedEventArgs e)
        {
            ((App)Application.Current).bTopMost = chk_TopMost.IsChecked.Value;
            ((App)Application.Current).UpdateSettings();
        }

        private void chk_TopMost_Unchecked(object sender, RoutedEventArgs e)
        {
            ((App)Application.Current).bTopMost = chk_TopMost.IsChecked.Value;
            ((App)Application.Current).UpdateSettings();
        }

        private void chk_ResizeGrip_Checked(object sender, RoutedEventArgs e)
        {
            ((App)Application.Current).resizeMode = ResizeMode.CanResizeWithGrip;
            ((App)Application.Current).UpdateSettings();
        }

        private void chk_ResizeGrip_Unchecked(object sender, RoutedEventArgs e)
        {
            ((App)Application.Current).resizeMode = ResizeMode.CanResize;
            ((App)Application.Current).UpdateSettings();
        }

        private void rdbtn_DarkTheme_Checked(object sender, RoutedEventArgs e)
        {
            rdbtn_LightTheme.IsChecked = false;
            ((App)Application.Current).iAppTheme = 0;
            ((App)Application.Current).UpdateSettings();
        }

        private void rdbtn_LightTheme_Checked(object sender, RoutedEventArgs e)
        {
            rdbtn_DarkTheme.IsChecked = false;
            ((App)Application.Current).iAppTheme = 1;
            ((App)Application.Current).UpdateSettings();
        }
    }
}
