﻿using SimplePallete.Models;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SimplePallete
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        OptionsWindow optionsWindow;
        ColorPickerWindow colorPickerWindow;

        private List<PlaceableObject> placeableObjects = new List<PlaceableObject>();
        private Point contextMenuOrigin;
        private Point startPoint;
        private bool isDragging = false;

        public Color defaultColor;

        public MainWindow()
        {
            ((App)Application.Current).SetMainWindowReference(this);

            InitializeComponent();
            defaultColor = GetColorFromClipboard();
            //Set the selected colour of the pallete here

            Topmost = ((App)Application.Current).bTopMost;
        }
        public void OpenOptions()
        {
            optionsWindow = new OptionsWindow();
            optionsWindow.Show();
        }
        public void ExitApplication()
        {
            Application.Current.Shutdown();
        }

        // Logic Functions
        private void AddPlaceableObject(PlaceableObject obj, Point point)
        {
            placeableObjects.Add(obj);

            UIElement uIElement = null;

            if ( obj is ColorObject colorObject)
            {
                uIElement = new Rectangle
                {
                    Width = 20,
                    Height = 20,
                    Fill = new SolidColorBrush(defaultColor),
                    Margin = new Thickness(point.X, point.Y, 0, 0)
                };
            }
            if ( obj is NoteObject noteObject)
            {
                uIElement = new TextBox
                {
                    Height = 20,
                    Text = noteObject.note,
                    Margin = new Thickness(point.X, point.Y, 0, 0)
                };
            }

            if (uIElement != null) 
            { 
                canvasObjects.Children.Add(uIElement);
            }
        }
        private void AddColorToPalette(Color col, Point point)
        {
            ColorObject colorObject = new ColorObject
            {
                color = col,
                X = point.X,
                Y = point.Y
            };

            AddPlaceableObject(colorObject, point);

            colorPickerWindow = new ColorPickerWindow(colorObject);
            colorPickerWindow.Show();
        }
        void AddNoteToPalette(String text, Point point)
        {
            NoteObject noteObject = new NoteObject
            {
                note = Clipboard.GetText(),
                X = point.X,
                Y = point.Y
            };
        }

        private Color GetColorFromClipboard()
        {
            string clipboardText = Clipboard.GetText();
            /*
            if(ColorHelper.TryConvertToColor(clipboardText, out Color defaultColor))
            {
                return defaultColor;
            }
            */
            return Colors.White;
        }

        private void CopyToClipboard(string info)
        {
            Clipboard.SetText(info);
        }

        // Input Bindings

        private void ctx_AddColour_Click(object sender, RoutedEventArgs e)
        {
            // For some reason the point gets offset by 20 pixels on y.
            // An extra 10 is added on each axis to that the object appears in the center.
            startPoint.X -= 10;
            startPoint.Y -= 30;

            AddColorToPalette(defaultColor, startPoint);
        }

        private void frm_Main_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            ctx_MainContextMenu.IsOpen = true;
            startPoint = Mouse.GetPosition(frm_Main);
            contextMenuOrigin = Mouse.GetPosition(frm_Main);
        }

        private void ctx_ExitApp_Click(object sender, RoutedEventArgs e)
        {
            ExitApplication();
        }

        private void ctx_OptionsMenu_Click(object sender, RoutedEventArgs e)
        {
            OpenOptions();
        }

        private void rect_TopDragArea_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if(e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }
        private void canvasObjects_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging && e.LeftButton == MouseButtonState.Pressed)
            {
                Point currentPosition = e.GetPosition(canvasObjects);

                foreach (UIElement child in canvasObjects.Children)
                {
                    if (child is FrameworkElement element)
                    {
                        double deltaX = currentPosition.X - startPoint.X;
                        double deltaY = currentPosition.Y - startPoint.Y;

                        double newLeft = Canvas.GetLeft(element) + deltaX;
                        double newTop = Canvas.GetTop(element) + deltaY;

                        Canvas.SetLeft(element, newLeft);
                        Canvas.SetTop(element, newTop);
                    }
                }

                startPoint = currentPosition;
            }
        }

        private void canvasObjects_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            startPoint = e.GetPosition(canvasObjects);
        }

        private void canvasObjects_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
        }

        private void ctx_AddNote_Checked(object sender, RoutedEventArgs e)
        {
            startPoint.X -= 10;
            startPoint.Y -= 30;

            AddNoteToPalette(Clipboard.GetText(), startPoint);
        }
    }
}