﻿using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Windows;
using System.Windows.Media;

namespace SimplePallete
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Settings
        public bool bTopMost = true;
        public ResizeMode resizeMode;

        // 0 = Dark, 1 = Light, Is an integer for future-proofing.
        public int iAppTheme = 0;
        public Color cDefaultColor = Colors.White;

        // Window References
        public MainWindow MainWindowReference { get; set; }
        public OptionsWindow OptionsWindowReference {  get; set; }
        public ColorPickerWindow ColorPickerWindowReference {  get; set; }

        // Process
        public void UpdateSettings()
        {
            MainWindowReference.Topmost = bTopMost;
            OptionsWindowReference.Topmost = bTopMost;

            MainWindowReference.ResizeMode = resizeMode;
            OptionsWindowReference.ResizeMode = resizeMode;

            SetTheme(iAppTheme);
        }


        //  Set References
        public void SetMainWindowReference(MainWindow mainWindow)
        {
            MainWindowReference = mainWindow;
        }
        public void SetOptionsWindowReference(OptionsWindow optionsWindow)
        {
            OptionsWindowReference = optionsWindow;
        }
        public void SetColorPickerWindowReference(ColorPickerWindow colorPickerWindow)
        {
            ColorPickerWindowReference = colorPickerWindow;
        }

        public void SetTheme(int iTheme)
        {
            switch(iTheme) 
            {
                case 0:
                    
                    break;
                case 1:

                    break;
                default:

                    break;
            }
        }
    }

}
